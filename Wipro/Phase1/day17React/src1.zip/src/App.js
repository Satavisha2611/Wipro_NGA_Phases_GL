import React from 'react';
import {Routes, Route} from 'react-router-dom';
import './App.css';
import AboutUs from './classComponents/AboutUs';
import ContactUs from './classComponents/ContactUs';
import Menu from './Menu ';
import Home from './classComponents/Home';

function App() {
  return (
     <><Menu>
      <Routes>
      <Route path='./classComponents/AboutUs.js' element={<AboutUs />}></Route>
      <Route path='./classComponents/ContactUs.js' element={<ContactUs />}></Route>
      <Route path='./classComponents/Home.js' element={<Home />}></Route>
      </Routes>
      </Menu></>
  );
}

export default App;
