import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import HeaderComponent from './components/Header';
import Paragraph from './components/Paragraph';
import Footer from './components/Footer';

class Menu extends React.Component
{
    render()
    {
      return(
        <><HeaderComponent></HeaderComponent>
        <Paragraph></Paragraph>
        <Footer></Footer></>
      );
    }
}
export default Menu;