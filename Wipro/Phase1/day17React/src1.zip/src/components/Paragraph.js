import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Paragraph.css'
function Paragraph()
{
    return(
        <main className='container mt-5'>
            <div className='row'>
                <div className='col-md-8'>
                    <h1 className='text-primary'>Welcome to the Training.</h1>
                </div>
            </div>
        </main>
    );
}

export default Paragraph;