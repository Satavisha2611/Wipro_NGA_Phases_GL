import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Header.css';

function HeaderComponent()
{
    return (
       <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container-fluid">
            <a className="navbar-brand" href= "/">App</a>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className='navbar-toggler-icon'></span>
            </button>

            <div className='collapse navbar-collapse' id="navbarNav">
                <ul className='navbar-nav ms-auto'>
                    <li className='nav-item'><a className='nav-link active' href="../classComponents/Home.js">Home</a></li>
                    <li className='nav-item'><a className='nav-link' href="../classComponents/AboutUs.js">About Us</a></li>
                    <li className='nav-item'><a className='nav-link' href="../classComponents/ContactUs.js">Contact Us</a></li>
                </ul>
                <form className='d-flex'>
                    <input className="form-control me-2" type="search" placeholder="Search" aria-label='Search' />
                    <button className="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
       </nav>
    );
}

export default HeaderComponent;

