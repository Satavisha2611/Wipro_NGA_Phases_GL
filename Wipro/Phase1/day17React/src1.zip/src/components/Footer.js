import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './Footer.css';

function Footer()
{
    return (
        <footer className="bg-dark text-light text-center py-3 mt-5">
            <p>Rights Reserved.</p>
        </footer>
    );
}

export default Footer;