import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from '../components/Header';
import Main from '../components/Paragraph';
import Footer from '../components/Footer';

function AboutUs()
{
    return(
        <><Header></Header><Main><p>This is the About Us.</p></Main><Footer></Footer></>
    );
}
export default AboutUs;