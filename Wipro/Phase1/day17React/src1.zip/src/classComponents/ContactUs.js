import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from '../components/Header';
import Main from '../components/Paragraph';
import Footer from '../components/Footer';

function ContactUs()
{
    return(
        <><Header></Header><Main><p>This is the Contact Us.</p></Main><Footer></Footer></>
    );
}
export default ContactUs;